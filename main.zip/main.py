from kivy.uix.actionbar import Label
from kivy.app import App
from kivy.uix import label

class MeuTexto(App):
    def build(self):

        return Label(
            text="Hello World",
            font_size=40,
            halign="center",
            valign="middle"
        ) 
    
if __name__ == '__main__':
    MeuTexto().run()