from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.core.window import Window

Window.size = (400,600)

class Bemvindo(App):
    def build(self):

        layout = BoxLayout(orientation='vertical', padding=30, spacing=20)

        titulo = Label(
            text='App de boas-vindas',
            font_size=32,
            bold=True,
            color=(0.2, 0.6, 0.86, 1),
            size_hint=(1, 0.2)
        )
        layout.add_widget(titulo)

        layout.add_widget(Label(size_hint=(1, 0.05)))

        self.input_nome = TextInput(
            hint_text='Digite seu nome...',
            multiline=False,
            font_size=22,
            size_hint=(1, 0.15),
            padding_y=(10,10),
            background_color=(0.9,0.9,0.95,1),
            foreground_color=(0,0,0,1),
            cursor_color=(0.2,0.6,0.86,1),
        )
        layout.add_widget(self.input_nome)

        botao = Button(
            text='Enviar',
            font_size=24,
            size_hint=(1, 0.15),
            background_color=(0.2, 0.6, 0.86, 1),
            color=(1, 1, 1, 1),
            bold=True
        )
        botao.bind(on_press=self.mostrar_mensagem)  # chama o método da classe
        layout.add_widget(botao)

        self.label_mensagem = Label(
            text='',
            font_size=22,
            halign='center',
            valign='middle',
            color=(0.1, 0.1, 0.1, 1),
            size_hint=(1, 0.3)
        )
        self.label_mensagem.bind(size=self.label_mensagem.setter('text_size'))
        layout.add_widget(self.label_mensagem)

        return layout
    
    # ← o método precisa estar **dentro da classe**
    def mostrar_mensagem(self, instance):
        nome = self.input_nome.text.strip()
        if nome:
            self.label_mensagem.text = f'Bem-vindo(a), {nome}!'
        else:
            self.label_mensagem.text = 'Por favor, digite seu nome.'

if __name__ == '__main__':
    Bemvindo().run()
